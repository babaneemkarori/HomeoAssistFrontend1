import { apiRequest } from "./queryClient";

export interface PaymentOrder {
  id: string;
  amount: number;
  currency: string;
  receipt: string;
  status: string;
}

export interface PaymentResult {
  success: boolean;
  paymentId?: string;
  orderId?: string;
  signature?: string;
  message: string;
}

declare global {
  interface Window {
    Razorpay: any;
  }
}

export class PaymentClient {
  private razorpayKeyId: string;

  constructor() {
    this.razorpayKeyId = import.meta.env.VITE_RAZORPAY_KEY_ID || "rzp_test_key";
  }

  async createOrder(amount: number, plan: string): Promise<PaymentOrder> {
    try {
      const response = await apiRequest("POST", "/api/payment/create-order", {
        amount,
        plan,
      });
      
      const result = await response.json();
      return result.order;
    } catch (error) {
      console.error("Failed to create payment order:", error);
      throw new Error("Failed to create payment order");
    }
  }

  async initializeRazorpay(
    order: PaymentOrder,
    plan: string,
    userEmail: string,
    userName?: string,
    onSuccess?: (result: any) => void,
    onFailure?: (error: any) => void
  ): Promise<void> {
    return new Promise((resolve, reject) => {
      // Load Razorpay script if not already loaded
      if (!window.Razorpay) {
        const script = document.createElement("script");
        script.src = "https://checkout.razorpay.com/v1/checkout.js";
        script.onload = () => this.openRazorpayCheckout(order, plan, userEmail, userName, onSuccess, onFailure, resolve, reject);
        script.onerror = () => reject(new Error("Failed to load Razorpay"));
        document.head.appendChild(script);
      } else {
        this.openRazorpayCheckout(order, plan, userEmail, userName, onSuccess, onFailure, resolve, reject);
      }
    });
  }

  private openRazorpayCheckout(
    order: PaymentOrder,
    plan: string,
    userEmail: string,
    userName?: string,
    onSuccess?: (result: any) => void,
    onFailure?: (error: any) => void,
    resolve?: () => void,
    reject?: (error: Error) => void
  ) {
    const options = {
      key: this.razorpayKeyId,
      amount: order.amount,
      currency: order.currency,
      name: "HomeoAI",
      description: `${plan} subscription`,
      order_id: order.id,
      handler: (response: any) => {
        onSuccess?.(response);
        resolve?.();
      },
      prefill: {
        email: userEmail,
        name: userName,
      },
      theme: {
        color: "#3B9EE0",
      },
      modal: {
        ondismiss: () => {
          const error = new Error("Payment cancelled by user");
          onFailure?.(error);
          reject?.(error);
        },
      },
    };

    const rzp = new window.Razorpay(options);
    rzp.open();
  }

  async verifyPayment(
    paymentId: string,
    orderId: string,
    signature: string,
    plan: string,
    amount: number
  ): Promise<PaymentResult> {
    try {
      const response = await apiRequest("POST", "/api/payment/verify", {
        paymentId,
        orderId,
        signature,
        plan,
        amount,
      });
      
      const result = await response.json();
      return {
        success: result.success,
        paymentId,
        orderId,
        signature,
        message: result.success ? "Payment verified successfully" : "Payment verification failed",
      };
    } catch (error) {
      console.error("Payment verification failed:", error);
      return {
        success: false,
        message: "Payment verification failed",
      };
    }
  }

  generateUPILink(amount: number, plan: string): string {
    const upiId = "pandeykamalakar@ybl";
    const name = "Kamalakar Pandey";
    const note = `HomeoAI ${plan} subscription`;
    
    return `upi://pay?pa=${upiId}&pn=${encodeURIComponent(name)}&am=${amount}&cu=INR&tn=${encodeURIComponent(note)}`;
  }

  async processUPIPayment(amount: number, plan: string): Promise<PaymentResult> {
    try {
      const response = await apiRequest("POST", "/api/payment/upi", {
        amount,
        plan,
      });
      
      const result = await response.json();
      return {
        success: result.success,
        message: result.success ? "UPI payment successful" : "UPI payment failed",
      };
    } catch (error) {
      console.error("UPI payment failed:", error);
      return {
        success: false,
        message: "UPI payment failed",
      };
    }
  }

  openUPIApp(amount: number, plan: string): void {
    const upiLink = this.generateUPILink(amount, plan);
    window.open(upiLink, "_self");
  }

  async simulatePaymentForDemo(plan: string, amount: number): Promise<PaymentResult> {
    // This is for demo purposes only - in production, remove this method
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          success: true,
          paymentId: `demo_pay_${Date.now()}`,
          orderId: `demo_order_${Date.now()}`,
          signature: `demo_sig_${Date.now()}`,
          message: "Demo payment successful",
        });
      }, 2000);
    });
  }
}

export const paymentClient = new PaymentClient();
