import { useAuth } from "@/hooks/use-auth";
import { useSubscription } from "@/hooks/use-subscription";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { 
  MessageSquare, 
  BookOpen, 
  TrendingUp, 
  Users, 
  Calendar, 
  AlertCircle,
  CheckCircle,
  Clock,
  Heart
} from "lucide-react";

export default function Dashboard() {
  const { user } = useAuth();
  const { subscription, hasActiveSubscription } = useSubscription();

  const { data: consultations, isLoading: consultationsLoading } = useQuery({
    queryKey: ["/api/consultations", user?.id],
    enabled: !!user?.id,
  });

  const { data: healthRecords, isLoading: recordsLoading } = useQuery({
    queryKey: ["/api/health-records", user?.id],
    enabled: !!user?.id,
  });

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card>
          <CardContent className="p-6 text-center">
            <AlertCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Please login to access your dashboard</p>
            <Link href="/login">
              <Button className="mt-4">Login</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-8 px-4" data-testid="dashboard">
      <div className="max-w-7xl mx-auto">
        {/* Welcome Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2" data-testid="welcome-title">
            Welcome back, {user.name || user.email}!
          </h1>
          <p className="text-muted-foreground">
            Your comprehensive homeopathic healthcare dashboard
          </p>
        </div>

        {/* Subscription Status */}
        {!hasActiveSubscription && (
          <Card className="mb-8 border-accent bg-accent/10" data-testid="subscription-warning">
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <AlertCircle className="w-8 h-8 text-accent" />
                <div className="flex-1">
                  <h3 className="font-semibold text-foreground">Subscription Required</h3>
                  <p className="text-muted-foreground">Please subscribe to access AI consultations and advanced features.</p>
                </div>
                <Link href="/subscription">
                  <Button className="bg-accent text-accent-foreground" data-testid="subscribe-button">
                    Subscribe Now
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-muted-foreground text-sm">Consultations</p>
                  <p className="text-2xl font-bold text-foreground" data-testid="consultations-count">
                    {consultationsLoading ? "-" : consultations?.length || 0}
                  </p>
                </div>
                <MessageSquare className="w-8 h-8 text-primary" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-muted-foreground text-sm">Health Records</p>
                  <p className="text-2xl font-bold text-foreground" data-testid="records-count">
                    {recordsLoading ? "-" : healthRecords?.length || 0}
                  </p>
                </div>
                <TrendingUp className="w-8 h-8 text-secondary" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-muted-foreground text-sm">Active Plan</p>
                  <p className="text-lg font-bold text-foreground capitalize" data-testid="active-plan">
                    {subscription?.plan || "None"}
                  </p>
                </div>
                <Users className="w-8 h-8 text-accent" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-muted-foreground text-sm">Plan Status</p>
                  <div className="flex items-center space-x-2">
                    {hasActiveSubscription ? (
                      <>
                        <CheckCircle className="w-4 h-4 text-secondary" />
                        <span className="text-sm font-semibold text-secondary">Active</span>
                      </>
                    ) : (
                      <>
                        <Clock className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground">Inactive</span>
                      </>
                    )}
                  </div>
                </div>
                <Calendar className="w-8 h-8 text-muted-foreground" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <Link href="/chat">
            <Card className="cursor-pointer hover:shadow-lg transition-shadow" data-testid="quick-action-chat">
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <MessageSquare className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">Start AI Consultation</h3>
                    <p className="text-sm text-muted-foreground">Get instant remedy suggestions</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>

          <Link href="/reference">
            <Card className="cursor-pointer hover:shadow-lg transition-shadow" data-testid="quick-action-reference">
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center">
                    <BookOpen className="w-6 h-6 text-accent" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">Browse Reference</h3>
                    <p className="text-sm text-muted-foreground">Search remedies and materia medica</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>

          <Card className="cursor-pointer hover:shadow-lg transition-shadow" data-testid="quick-action-emergency">
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                  <Heart className="w-6 h-6 text-red-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">Emergency Remedies</h3>
                  <p className="text-sm text-muted-foreground">Quick access for urgent situations</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Recent Consultations */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                Recent Consultations
                <Link href="/chat">
                  <Button variant="outline" size="sm" data-testid="view-all-consultations">
                    View All
                  </Button>
                </Link>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {consultationsLoading ? (
                <div className="space-y-3">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="h-16 bg-muted rounded animate-pulse" />
                  ))}
                </div>
              ) : consultations?.length > 0 ? (
                <div className="space-y-4">
                  {consultations.slice(0, 3).map((consultation: any) => (
                    <div key={consultation.id} className="flex items-start space-x-3 p-3 bg-muted rounded-lg">
                      <MessageSquare className="w-5 h-5 text-primary mt-1" />
                      <div className="flex-1">
                        <p className="text-sm text-foreground truncate">{consultation.symptoms}</p>
                        <p className="text-xs text-muted-foreground">
                          {consultation.createdAt ? new Date(consultation.createdAt).toLocaleDateString() : "Recently"}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <MessageSquare className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">No consultations yet</p>
                  <Link href="/chat">
                    <Button className="mt-2" size="sm" data-testid="start-first-consultation">
                      Start Your First Consultation
                    </Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Health Progress */}
          <Card>
            <CardHeader>
              <CardTitle>Health Progress</CardTitle>
            </CardHeader>
            <CardContent>
              {recordsLoading ? (
                <div className="space-y-3">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="h-16 bg-muted rounded animate-pulse" />
                  ))}
                </div>
              ) : healthRecords?.length > 0 ? (
                <div className="space-y-4">
                  {healthRecords.slice(0, 3).map((record: any) => (
                    <div key={record.id} className="flex items-start space-x-3 p-3 bg-muted rounded-lg">
                      <TrendingUp className="w-5 h-5 text-secondary mt-1" />
                      <div className="flex-1">
                        <p className="text-sm text-foreground">{record.recordType}</p>
                        <p className="text-xs text-muted-foreground">
                          {record.familyMember} • {record.date ? new Date(record.date).toLocaleDateString() : "Recently"}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <TrendingUp className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
                  <p className="text-muted-foreground">No health records yet</p>
                  <p className="text-xs text-muted-foreground mt-1">Start tracking your health journey</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
