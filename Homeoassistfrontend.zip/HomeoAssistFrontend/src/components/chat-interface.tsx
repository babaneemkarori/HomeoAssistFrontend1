import { useState, useRef, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Bot, User, Send, Mic, Loader2, AlertTriangle } from "lucide-react";

interface Message {
  id: string;
  type: "user" | "ai";
  content: string;
  timestamp: Date;
  remedies?: any[];
  analysis?: any;
}

export default function ChatInterface() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      type: "ai",
      content: "Hello! I'm your AI homeopathy assistant. Please describe your symptoms in detail, and I'll help suggest appropriate remedies based on classical homeopathic principles.",
      timestamp: new Date(),
    }
  ]);
  const [inputValue, setInputValue] = useState("");
  const [isListening, setIsListening] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const analyzeMutation = useMutation({
    mutationFn: async (symptoms: string) => {
      const response = await apiRequest("POST", "/api/consultation/analyze", {
        userId: user?.id,
        symptoms,
        language: "en",
      });
      return response.json();
    },
    onSuccess: (data) => {
      const aiMessage: Message = {
        id: `ai-${Date.now()}`,
        type: "ai",
        content: `Based on your symptoms, I've analyzed your condition and found some relevant homeopathic remedies. Here are my suggestions:`,
        timestamp: new Date(),
        remedies: data.analysis?.remedies,
        analysis: data.analysis?.analysis,
      };
      setMessages(prev => [...prev, aiMessage]);
      
      queryClient.invalidateQueries({ queryKey: ["/api/consultations"] });
      
      toast({
        title: "Analysis complete",
        description: "AI has analyzed your symptoms and provided remedy suggestions.",
      });
    },
    onError: (error) => {
      toast({
        title: "Analysis failed",
        description: "Failed to analyze symptoms. Please try again.",
        variant: "destructive",
      });
      
      const errorMessage: Message = {
        id: `error-${Date.now()}`,
        type: "ai",
        content: "I apologize, but I encountered an error while analyzing your symptoms. Please try again or contact support if the issue persists.",
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, errorMessage]);
    },
  });

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: `user-${Date.now()}`,
      type: "user",
      content: inputValue,
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    const symptoms = inputValue;
    setInputValue("");

    // Analyze symptoms
    await analyzeMutation.mutateAsync(symptoms);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const startVoiceInput = () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      toast({
        title: "Voice input not supported",
        description: "Your browser doesn't support voice input.",
        variant: "destructive",
      });
      return;
    }

    setIsListening(true);
    // In a real implementation, you would use the Web Speech API here
    setTimeout(() => {
      setIsListening(false);
      setInputValue("I have been experiencing headaches and feel tired throughout the day");
      toast({
        title: "Voice input captured",
        description: "Your voice input has been converted to text.",
      });
    }, 2000);
  };

  const renderRemedies = (remedies: any[]) => {
    if (!remedies || remedies.length === 0) return null;

    return (
      <div className="mt-4 space-y-3">
        <p className="font-semibold text-foreground">Suggested Remedies:</p>
        {remedies.map((remedy, index) => (
          <div key={index} className="bg-muted p-3 rounded-lg border-l-4 border-primary">
            <div className="flex items-start justify-between mb-2">
              <h4 className="font-semibold text-foreground">{remedy.remedy}</h4>
              <Badge variant="outline">{Math.round(remedy.confidence * 100)}% match</Badge>
            </div>
            <p className="text-sm text-muted-foreground mb-2">{remedy.reasoning}</p>
            <div className="text-xs space-y-1">
              <p><strong>Potency:</strong> {remedy.potency}</p>
              <p><strong>Dosage:</strong> {remedy.dosage}</p>
              {remedy.safety && remedy.safety.length > 0 && (
                <div className="mt-2 p-2 bg-accent/10 rounded">
                  <p className="font-medium text-accent flex items-center">
                    <AlertTriangle className="w-3 h-3 mr-1" />
                    Safety Notes:
                  </p>
                  <ul className="text-xs text-muted-foreground mt-1">
                    {remedy.safety.map((note: string, idx: number) => (
                      <li key={idx}>• {note}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    );
  };

  return (
    <div className="bg-card rounded-xl shadow-lg border border-border" data-testid="chat-interface">
      {/* Chat Messages */}
      <div className="h-96 overflow-y-auto p-6 space-y-4" data-testid="chat-messages">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.type === "user" ? "justify-end" : "justify-start"}`}
          >
            <div className={`flex items-start space-x-3 max-w-[80%] ${message.type === "user" ? "flex-row-reverse space-x-reverse" : ""}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                message.type === "user" 
                  ? "bg-secondary" 
                  : "bg-primary"
              }`}>
                {message.type === "user" ? (
                  <User className="w-4 h-4 text-secondary-foreground" />
                ) : (
                  <Bot className="w-4 h-4 text-primary-foreground" />
                )}
              </div>
              
              <Card className={`${
                message.type === "user" 
                  ? "bg-primary text-primary-foreground" 
                  : "bg-card"
              }`}>
                <CardContent className="p-4">
                  <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                  {message.remedies && renderRemedies(message.remedies)}
                  <p className="text-xs opacity-70 mt-2">
                    {message.timestamp.toLocaleTimeString()}
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        ))}
        
        {analyzeMutation.isPending && (
          <div className="flex justify-start">
            <div className="flex items-start space-x-3">
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                <Bot className="w-4 h-4 text-primary-foreground" />
              </div>
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <p className="text-sm">Analyzing your symptoms...</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="border-t border-border p-6">
        <div className="flex space-x-2">
          <div className="flex-1 relative">
            <Input
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Describe your symptoms in detail..."
              className="pr-12"
              disabled={analyzeMutation.isPending}
              data-testid="chat-input"
            />
            <Button
              variant="ghost"
              size="sm"
              className="absolute right-2 top-1/2 transform -translate-y-1/2"
              onClick={startVoiceInput}
              disabled={isListening || analyzeMutation.isPending}
              data-testid="voice-input-button"
            >
              <Mic className={`w-4 h-4 ${isListening ? "text-red-500" : "text-muted-foreground"}`} />
            </Button>
          </div>
          <Button
            onClick={handleSendMessage}
            disabled={!inputValue.trim() || analyzeMutation.isPending}
            data-testid="send-message-button"
          >
            {analyzeMutation.isPending ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Send className="w-4 h-4" />
            )}
          </Button>
        </div>

        <div className="mt-4 text-xs text-muted-foreground">
          <p><strong>Tips:</strong> Be specific about your symptoms, including when they occur, what makes them better or worse, and how long you've had them.</p>
        </div>
      </div>
    </div>
  );
}
