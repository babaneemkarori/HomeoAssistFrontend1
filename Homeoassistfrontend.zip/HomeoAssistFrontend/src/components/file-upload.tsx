import { useState, useCallback } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  Upload, 
  FileText, 
  Image, 
  CheckCircle, 
  AlertCircle, 
  Loader2, 
  X, 
  Eye 
} from "lucide-react";

interface UploadedFile {
  id: string;
  fileName: string;
  fileType: string;
  processingStatus: string;
  extractedText?: string;
  createdAt: string;
}

export default function FileUpload() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [dragActive, setDragActive] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);

  const uploadMutation = useMutation({
    mutationFn: async (fileData: { fileName: string; fileType: string }) => {
      const response = await apiRequest("POST", "/api/files/upload", {
        userId: user?.id,
        ...fileData,
      });
      return response.json();
    },
    onSuccess: (data) => {
      setUploadedFiles(prev => [...prev, data.file]);
      toast({
        title: "File uploaded",
        description: "Your file has been uploaded and is being processed.",
      });
      
      // Poll for processing completion
      pollFileStatus(data.file.id);
    },
    onError: () => {
      toast({
        title: "Upload failed",
        description: "Failed to upload file. Please try again.",
        variant: "destructive",
      });
    },
  });

  const pollFileStatus = async (fileId: string) => {
    let attempts = 0;
    const maxAttempts = 30; // 30 seconds
    
    const poll = async () => {
      try {
        const response = await apiRequest("GET", `/api/files/${fileId}`);
        const result = await response.json();
        
        setUploadedFiles(prev => 
          prev.map(file => 
            file.id === fileId ? result.file : file
          )
        );

        if (result.file.processingStatus === "completed") {
          toast({
            title: "Processing complete",
            description: "Text has been extracted from your document.",
          });
        } else if (result.file.processingStatus === "failed") {
          toast({
            title: "Processing failed",
            description: "Failed to extract text from the document.",
            variant: "destructive",
          });
        } else if (attempts < maxAttempts) {
          setTimeout(poll, 1000);
          attempts++;
        }
      } catch (error) {
        console.error("Error polling file status:", error);
      }
    };

    setTimeout(poll, 1000);
  };

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFiles(e.dataTransfer.files);
    }
  }, []);

  const handleFiles = (files: FileList) => {
    const file = files[0];
    if (!file) return;

    // Validate file type
    const allowedTypes = ["application/pdf", "image/jpeg", "image/png", "image/jpg"];
    if (!allowedTypes.includes(file.type)) {
      toast({
        title: "Invalid file type",
        description: "Please upload PDF or image files only.",
        variant: "destructive",
      });
      return;
    }

    // Validate file size (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      toast({
        title: "File too large",
        description: "Please upload files smaller than 10MB.",
        variant: "destructive",
      });
      return;
    }

    uploadMutation.mutate({
      fileName: file.name,
      fileType: file.type,
    });
  };

  const removeFile = (fileId: string) => {
    setUploadedFiles(prev => prev.filter(file => file.id !== fileId));
  };

  const getFileIcon = (fileType: string) => {
    if (fileType.includes("pdf")) return <FileText className="w-8 h-8 text-red-500" />;
    if (fileType.includes("image")) return <Image className="w-8 h-8 text-blue-500" />;
    return <FileText className="w-8 h-8 text-muted-foreground" />;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed": return "text-secondary";
      case "failed": return "text-destructive";
      case "processing": return "text-accent";
      default: return "text-muted-foreground";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed": return <CheckCircle className="w-4 h-4" />;
      case "failed": return <AlertCircle className="w-4 h-4" />;
      case "processing": return <Loader2 className="w-4 h-4 animate-spin" />;
      default: return <Loader2 className="w-4 h-4 animate-spin" />;
    }
  };

  return (
    <div className="space-y-6" data-testid="file-upload">
      {/* Upload Area */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Upload className="w-5 h-5" />
            Upload Medical Documents
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div
            className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors cursor-pointer ${
              dragActive 
                ? "border-primary bg-primary/5" 
                : "border-border hover:border-primary hover:bg-muted/50"
            }`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
            onClick={() => document.getElementById("file-input")?.click()}
            data-testid="drop-zone"
          >
            <Upload className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-2">
              Drop medical documents here
            </h3>
            <p className="text-muted-foreground mb-4">
              or click to select files from your device
            </p>
            <p className="text-sm text-muted-foreground">
              Supports PDF, JPG, PNG (max 10MB)
            </p>
            
            <input
              id="file-input"
              type="file"
              className="hidden"
              accept=".pdf,.jpg,.jpeg,.png"
              onChange={(e) => e.target.files && handleFiles(e.target.files)}
              data-testid="file-input"
            />
          </div>

          {uploadMutation.isPending && (
            <div className="mt-4 p-4 bg-muted rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Loader2 className="w-4 h-4 animate-spin" />
                <p className="text-sm font-medium">Uploading...</p>
              </div>
              <Progress value={75} className="w-full" />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Uploaded Files */}
      {uploadedFiles.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Processing Status</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {uploadedFiles.map((file) => (
                <div
                  key={file.id}
                  className="flex items-center space-x-4 p-4 bg-muted rounded-lg"
                  data-testid={`uploaded-file-${file.id}`}
                >
                  {getFileIcon(file.fileType)}
                  
                  <div className="flex-1">
                    <p className="font-medium text-foreground">{file.fileName}</p>
                    <div className="flex items-center space-x-2 mt-1">
                      <div className={`flex items-center space-x-1 ${getStatusColor(file.processingStatus)}`}>
                        {getStatusIcon(file.processingStatus)}
                        <span className="text-sm capitalize">{file.processingStatus}</span>
                      </div>
                      <Badge variant="outline" className="text-xs">
                        {file.fileType.split("/")[1]?.toUpperCase()}
                      </Badge>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    {file.processingStatus === "completed" && file.extractedText && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          // Show extracted text in a modal or expand area
                          toast({
                            title: "Extracted Text",
                            description: file.extractedText?.substring(0, 100) + "...",
                          });
                        }}
                        data-testid={`view-extracted-text-${file.id}`}
                      >
                        <Eye className="w-4 h-4 mr-1" />
                        View Text
                      </Button>
                    )}
                    
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeFile(file.id)}
                      data-testid={`remove-file-${file.id}`}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Processing Instructions */}
      <Card>
        <CardContent className="p-6">
          <h3 className="font-semibold text-foreground mb-3">Processing Information</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div className="flex items-start space-x-2">
              <FileText className="w-4 h-4 text-primary mt-0.5" />
              <div>
                <p className="font-medium">OCR Processing</p>
                <p className="text-muted-foreground">Extracts text from images and PDFs</p>
              </div>
            </div>
            
            <div className="flex items-start space-x-2">
              <Bot className="w-4 h-4 text-secondary mt-0.5" />
              <div>
                <p className="font-medium">AI Analysis</p>
                <p className="text-muted-foreground">Analyzes extracted medical information</p>
              </div>
            </div>
            
            <div className="flex items-start space-x-2">
              <CheckCircle className="w-4 h-4 text-accent mt-0.5" />
              <div>
                <p className="font-medium">Remedy Suggestions</p>
                <p className="text-muted-foreground">Provides homeopathic recommendations</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
